int func(int a, float b) {
    return a+b;
}

void main () {
    int a, b, c, i;
    int e, f[10], g[11];
    a = 1;
    b = 2;
    c = func(a, b);

    float d;
}